const express = require('express')
const app = express()



const Sequelize = require("sequelize")


const sequelize = new Sequelize('themoviemanager', 'root', '', {
    dialect: 'mysql',
    host: 'localhost',
})


sequelize.authenticate().then(function(){
    console.log('success')
}).catch(function(){
    console.log('there was an error connecting to db')
})

const Movies = sequelize.define('movies', {
    imdb_id: {
        type: Sequelize.INTEGER,
        field: 'imdb_id'
    },
    title: {
        type: Sequelize.STRING,
        field: 'title'
    },
    release_date: {
        type: Sequelize.DATE,
        field: 'release_date'
    },
    homepage: {
        type: Sequelize.STRING,
        field: 'homepage'
    },
    rating: {
        type: Sequelize.INTEGER,
        filed: 'rating'
    },
    movie_type: {
        type: Sequelize.STRING,
        field: 'type'
    },
    overview: {
        type: Sequelize.TEXT,
        field: 'overview'
    }
});

const Genres = sequelize.define('genres', {
    name: {
        type: Sequelize.STRING,
        field: 'name'
    },
    description: {
        type: Sequelize.TEXT,
        field: 'description'
    }
});

const Cast = sequelize.define('cast', {
   
    character_name: {
        type: Sequelize.STRING,
        field: 'character_name'
    },
    role_type: {
        type: Sequelize.STRING,
        field: 'role_type'
    }
});

const Actors = sequelize.define('actors', {
    actor_name: {
        type: Sequelize.STRING,
        field: 'actor_name'
    },
    wiki_url: {
        type: Sequelize.STRING,
        field: 'wiki_url'
    }
});

const Users = sequelize.define('users', {
    password: {
        type: Sequelize.STRING,
        field: 'password'
    },
    name: {
        type: Sequelize.STRING,
        field: 'name'
    },
    join_date: {
        type: Sequelize.DATE,
        field: 'join_date'
    },
    description_id: {
        type: Sequelize.INTEGER,
        field: 'description_id'
    }
});

Movies.belongsTo(Users);
Movies.belongsTo(Genres);
Cast.belongsTo(Movies);
Cast.belongsTo(Actors);

app.use(express.json())
app.use(express.urlencoded())

app.use('/', express.static('static'))

app.get('/createdb', function(request, response){
    sequelize.sync({force:true}).then(function(){
        response.status(200).send('tables created')
    }).catch(function(){
        response.status(200).send('could not create tables')
    })
})

//metoda POST pentru tabela Cast

app.post('/cast', (request, response) => {
    Cast.create(request.body).then((result) => {
        response.status(201).json(result)
    }).catch((err) => {
        response.status(500).send("resource not created")
    })
})

//metoda GET pentru tabela Cast 
app.get('/getcast', (request, response) => {
    Cast.findAll().then((results) => {
        response.status(200).json(results)
    })
})

//metoda GET pt tabela Cast, dupa id
app.get('/getcast/:id',(request, response)=>{
    Cast.findById(request.params.id).then((result)=>{
       if(result) {
            response.status(200).json(result)
        } else {
            response.status(404).send('no resource found')
        }
    }).catch((err) => {
        console.log(err)
        response.status(500).send('database error')
    })
})

//metoda POST pt actors
app.post('/actors', (request, response) => {
    Actors.create(request.body).then((result) => {
        response.status(201).json(result)
    }).catch((err) => {
        response.status(500).send("resource not created")
    })
})

//metoda GET pentru actors
app.get('/getactors/:id',(request, response)=>{
    Cast.findById(request.params.id).then((result)=>{
       if(result) {
            response.status(200).json(result)
        } else {
            response.status(404).send('no resource found')
        }
    }).catch((err) => {
        console.log(err)
        response.status(500).send('database error')
    })
})


//metoda POST pt Users

app.post('/users', (request, response) => {
    Users.create(request.body).then((result) => {
        response.status(201).json(result)
    }).catch((err) => {
        response.status(500).send("resource not created")
    })
})

//metoda GET pentru users
app.get('/getusers/:id',(request, response)=>{
    Users.findById(request.params.id).then((result)=>{
       if(result) {
            response.status(200).json(result)
        } else {
            response.status(404).send('no resource found')
        }
    }).catch((err) => {
        console.log(err)
        response.status(500).send('database error')
    })
})


app.listen(8080)