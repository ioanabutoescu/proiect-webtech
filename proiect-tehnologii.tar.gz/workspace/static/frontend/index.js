function goToWelcome(){
    location.replace("welcome.html")
}